﻿using System;

namespace loop_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;

            for(i=1;i<=5;i++)
            {
                Console.Write(i);

            }
            
        }
    }
}

﻿using System;

namespace arithmetic_operator
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;
            Console.WriteLine("enter value of a&b:");
            a = Convert.ToInt32(Console.ReadLine());
            b= Convert.ToInt32(Console.ReadLine());
            c = a + b;
            Console.WriteLine("add:"+c);
            c = a - b;
            Console.WriteLine("sub:" + c);
            c = a * b;
            Console.WriteLine("mul:" + c);
            c = a / b;
            Console.WriteLine("div:" + c);
            c = a % b;
            Console.WriteLine("mod:" + c);
            Console.Read();
        }
    }
}

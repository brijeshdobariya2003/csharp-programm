﻿using System;

namespace boxing_unboxing
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 5;
            object obj = a;  //boxing
            Console.WriteLine("obj type var:" + obj);

            int b = (int)obj;   //unboxing
            Console.WriteLine("value type var:" + b);

            Console.Read();
        }
    }
}

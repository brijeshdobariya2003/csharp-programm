﻿using System;

namespace relational_operator
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            Console.WriteLine("enter value of a&b:");
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());

            if (a >= b)
                Console.Write(a + "is greter");
           else if (a <= b)
                Console.Write(a + "is smaller");
           else if (a == b)
                Console.Write(a + "&"+b+"are equal");
            else if (a != b)
                Console.Write("a no equal b");
            Console.Read();

        }
    }
}

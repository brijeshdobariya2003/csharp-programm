﻿using System;

namespace rows2
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, a = 1, b = 2, n;
            Console.Write("enter n:");
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(a + "" + b + "");
            for(i=3;i<=n;i++)
            {
                if(i%2==1)
                {
                    a = a * 3;
                    Console.Write(a + "");
                }
                else
                {
                    b = b * 3;
                    Console.Write(b + "");
                }
            }
            Console.WriteLine("whileloop:");
            i = 3;a = 1;b = 2;
            Console.WriteLine(a + "" + b + "");
            while(i<=n)
            {
                if(i%2==1)
                {
                    a = a * 3;
                    Console.Write(a + "");
                }
                else
                {
                    b = b * 3;
                    Console.Write(b + "");
                }
                i++;
            }
            Console.WriteLine("do..while loop");
           int i = 3;a = 1; b = 2; n;
            Console.WriteLine(a + "" + b + "");
            do
            {
                if (i % 2 == 1)
                {
                    a = a * 3;
                    Console.WriteLine(a + "");
                }
                else
                {
                    b = b * 3;
                    Console.Write(b + "");
                }
                i++;
            }
            while (i <= n);
            Console.Read();




        }
    }
}

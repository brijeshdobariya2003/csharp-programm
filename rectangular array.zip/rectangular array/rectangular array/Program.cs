﻿using System;

namespace multidimensional_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[2, 2] { { 2, 1 }{ 3, 4 } };
            int i, j;

            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 6; j++)
                {

                    Console.Write(a[i, j]);
                }
                Console.WriteLine();
            }
            Console.Read();
        }
    }
}

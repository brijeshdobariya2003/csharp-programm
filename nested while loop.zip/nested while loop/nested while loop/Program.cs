﻿using System;

namespace nested_while_loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;j = 1;
            while(i<=5)
            {
                while(j<=5)
                {
                    Console.Write(j + "");
                    j++;
                }
                i++;
            }
        }
    }
}

﻿using System;

namespace fibonnaci_series
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, i, a = 0, b = 1, c;
            Console.Write("Input n:");
            n = Convert.ToInt32(Console.ReadLine());
            for(i=a;i<=n;i++)
            {
                Console.Write(a + "");
                c = a + b;
                a = b;
                b = c;

            }
            Console.WriteLine("while loop:");
            a = 0;b = 1;i = a;
            while(i<=n)
            {
                Console.Write(a + "");
                c = a + b;
                a = b;
                b = c;
                i++;
            }
            Console.WriteLine("do..while loop");
            a = 0;b = 1;i = a;

            do
            {
                Console.Write(a + "");
                c = a + b;
                a = b;
                b = c;
                i++;
            }
            while (i <= n);

            Console.Read();
        }
    }
}

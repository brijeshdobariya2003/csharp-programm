﻿using System;

namespace do_while_loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            do
            {
                Console.Write(i);
                i++;
            }
            while (i <= 5);
        }
    }
}

﻿using System;

namespace nested_do_while
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1; j = 1;
            do
            {
                Console.Write(j + "");
                j++;

            }
            while (j <= i);
            i++;

        }
        while(i<=5);
    }
}

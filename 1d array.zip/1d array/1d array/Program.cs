﻿using System;

namespace _1d_array
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] str = new string[5];
            int i;

            
            Console.WriteLine("enter name:");
            for(i=0;i<5;i++)
            {

                str[i] = Console.ReadLine();
                Console.WriteLine(str[i]);

            }
            Console.Read();
        }
    }
}

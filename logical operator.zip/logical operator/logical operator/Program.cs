﻿using System;

namespace logical_operator
{
    class Program
    {
        static void Main(string[] args)
        {
            int s1, s2, s3;
            Console.WriteLine("enter s1,s2,s3:");

            s1 = Convert.ToInt32(Console.ReadLine());
            s2 = Convert.ToInt32(Console.ReadLine());
            s3 = Convert.ToInt32(Console.ReadLine());

            if (s1 <= 30 && s2 <= 30 && s3 <= 30)

                Console.WriteLine("you are pass");

            else if (s1 >= 30 || s2 >= 30 || s3 >= 30)

                Console.WriteLine("atkt");
            else

                Console.WriteLine("fail");
            Console.Read();

        }
    }
}

﻿using System;

namespace loop2
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            while(i<=5)
            {
                Console.Write(i);
                i++;
            }
        }
    }
}
